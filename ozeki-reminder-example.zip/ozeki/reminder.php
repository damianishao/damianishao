<?php
//include the database handler class
include("ozekiDB.class.php");


//saving variables from the post array
$phoneNumber = $_POST['phone'];
$date = $_POST['date'];
$time = $_POST['time'];
$reminderType = $_POST['reminder_type'];
$comment = $_POST['comment'];


//inserting an outgoind message into the database
$db = new OzekiDB();
$query = $db->SetOutgoingMessage($phoneNumber,"Selected reminder type: ".$reminderType.", Your comment: ".$comment, $date." ".$time);

//checking if insertion was successful
if (!$query)
	echo '<h1>An error occored while trying to insert a row into the database.<h1>';
else
	echo '<h1>Reminder created successfully</h1>';

?>